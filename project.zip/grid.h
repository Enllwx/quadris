#ifndef _GRID_H_
#define _GRID_H_

#include <vector>
#include <iostream>
#include <memory>
#include "type.h"
#include "cell.h"
#include "blockholder.h"
#include "hintgenerator.h"
#include "textdisplay.h"
#include "score.h"

class Grid : public std::enable_shared_from_this<Grid> {
    int width, height;
    Level difficultyLevel = Level::lvl0;
    std::vector<std::vector <Cell>> board;
    BlockHolder theHolder;
    TextDisplay td;
    bool showHint = false;
    bool rowCleared = false;
    // GraphicDisplay* gd = nullptr;
    ScoreCounter score;
    // point to same place as "difficultyLevel" in BlockHolder
    std::string defaultLoadPath = "sequence.txt";
    void showCurrentPosition();
    void eliminateRow();
    
public:
    Grid(int w = 11, int h = 15, Level d = Level::lvl0, bool textOnly = true);     // ctor
    void init(std::string defaultPath = "sequence.txt", Level level = Level::lvl0);
    
    Cell getCell(int row, int col);
    void setCell(int row, int col, Cell c);
    bool cellOccupied(int row, int col);
    
    int getWidth();
    int getHeight();
    
    Level getLevel();
    
    int getScore();
    int getHighScore();
    
    BlockHolder& getBlockHolder();
    Block & getNextBlock();
    Block & getCurrentBlock();
    void update();      // update() the board (may eliminate lines)
    void updateBoard();
    void clear();       // clear() clear the board
    void hint();        // hint() give the best solution of current block
    bool shouldShowHint();
    Block getHint();
    bool gameOver();    // gameOver() determine if the game is over
    void changeLevel(int num);
    void mutate(Move cmd, const int num = 1);
    void changeShape(Shape s);
    std::shared_ptr<Difficulty> getDifficulty();
    void setLoadPath(std::string path);
    std::string getDefaultLoadPath();
    bool justClearedRow();
    
    friend std::ostream &operator<<(std::ostream &out, Grid &g);
};

#endif /* grid_hpp */

